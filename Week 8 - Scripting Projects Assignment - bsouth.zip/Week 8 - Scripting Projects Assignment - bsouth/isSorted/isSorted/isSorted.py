def isSorted(lst):
    if len(lst) <= 1:
        return True
    
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False
    
    return True

# Test cases
print(isSorted([1, 2, 3, 4, 5])) # True
print(isSorted([5, 4, 3, 2, 1])) # False
print(isSorted([1, 3, 2, 4, 5])) # False
print(isSorted([1]))            # True
print(isSorted([]))             # True
print(isSorted([1, 2, 2, 3]))   # True
