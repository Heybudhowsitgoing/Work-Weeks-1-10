import tkinter as tk
from tkinter import ttk

def calculate_tax():
    try:
        gross_income = float(gross_income_entry.get())
        num_dependents = int(dependents_entry.get())
        
        STANDARD_DEDUCTION = 10000
        DEPENDENT_DEDUCTION = 3000
        TAX_RATE = 0.2
        
        taxable_income = gross_income - STANDARD_DEDUCTION - (DEPENDENT_DEDUCTION * num_dependents)
        taxable_income = max(0, taxable_income)  
        
        total_tax = taxable_income * TAX_RATE
        total_tax_label.config(text=f"{total_tax:.2f}")
    except ValueError:
        total_tax_label.config(text="Invalid input")

root = tk.Tk()
root.title("Tax Calculator")

ttk.Label(root, text="Gross income").grid(column=0, row=0, padx=10, pady=5)
gross_income_entry = ttk.Entry(root)
gross_income_entry.grid(column=1, row=0, padx=10, pady=5)

ttk.Label(root, text="Dependents").grid(column=0, row=1, padx=10, pady=5)
dependents_entry = ttk.Entry(root)
dependents_entry.grid(column=1, row=1, padx=10, pady=5)

compute_button = ttk.Button(root, text="Compute", command=calculate_tax)
compute_button.grid(column=0, row=2, columnspan=2, pady=10)

ttk.Label(root, text="Total tax").grid(column=0, row=3, padx=10, pady=5)
total_tax_label = ttk.Label(root, text="0.0")
total_tax_label.grid(column=1, row=3, padx=10, pady=5)

root.mainloop()

