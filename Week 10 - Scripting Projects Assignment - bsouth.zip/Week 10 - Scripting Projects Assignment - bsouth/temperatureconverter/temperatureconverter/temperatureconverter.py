import tkinter as tk
from tkinter import ttk

def fahrenheit_to_celsius():
    try:
        fahrenheit = float(fahrenheit_entry.get())
        celsius = (fahrenheit - 32) * 5 / 9
        celsius_entry.delete(0, tk.END)
        celsius_entry.insert(0, f"{celsius:.2f}")
    except ValueError:
        celsius_entry.delete(0, tk.END)
        celsius_entry.insert(0, "Invalid input")

def celsius_to_fahrenheit():
    try:
        celsius = float(celsius_entry.get())
        fahrenheit = (celsius * 9 / 5) + 32
        fahrenheit_entry.delete(0, tk.END)
        fahrenheit_entry.insert(0, f"{fahrenheit:.2f}")
    except ValueError:
        fahrenheit_entry.delete(0, tk.END)
        fahrenheit_entry.insert(0, "Invalid input")

root = tk.Tk()
root.title("Temperature Converter")

ttk.Label(root, text="Fahrenheit").grid(column=0, row=0, padx=10, pady=5)
ttk.Label(root, text="Celsius").grid(column=1, row=0, padx=10, pady=5)

fahrenheit_entry = ttk.Entry(root)
fahrenheit_entry.grid(column=0, row=1, padx=10, pady=5)
fahrenheit_entry.insert(0, "32.0")

celsius_entry = ttk.Entry(root)
celsius_entry.grid(column=1, row=1, padx=10, pady=5)
celsius_entry.insert(0, "0.0")

to_celsius_button = ttk.Button(root, text=">>>>", command=fahrenheit_to_celsius)
to_celsius_button.grid(column=0, row=2, padx=10, pady=10)

to_fahrenheit_button = ttk.Button(root, text="<<<<", command=celsius_to_fahrenheit)
to_fahrenheit_button.grid(column=1, row=2, padx=10, pady=10)

root.mainloop()

