from PIL import Image

def grayscale(image):
    """Convert the image to grayscale."""
    return image.convert("L").convert("RGB")

def sepia(image_path, output_path):
    """Convert a color image to sepia."""
    image = Image.open(image_path)
    image = grayscale(image)
    
    pixels = image.load()
    for y in range(image.height):
        for x in range(image.width):
            red, green, blue = pixels[x, y]
            if red < 63:
                red = int(red * 1.1)
                blue = int(blue * 0.9)
            elif red < 192:
                red = int(red * 1.15)
                blue = int(blue * 0.85)
            else:
                red = min(int(red * 1.08), 255)
                blue = int(blue * 0.93)
            pixels[x, y] = (red, green, blue)

    image.save(output_path)
    image.show()  # Display the image

# Example usage
if __name__ == "__main__":
    input_image_path = r"C:\Users\brade\source\repos\koch\FELV-cat.jpg"  # Use raw string literal
    output_image_path = r"C:\Users\brade\source\repos\koch\FELV-cat.jpg"  # Use raw string literal
    sepia(input_image_path, output_image_path)
    print("Sepia conversion complete.")
