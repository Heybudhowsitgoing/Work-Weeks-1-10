def read_numbers_from_file(filename):
    """
    Reads lines from the specified file and returns a list of numbers.
    
    Args:
    filename (str): The name of the file to read from.
    
    Returns:
    list of float: The list of numbers read from the file.
    """
    try:
        with open(filename, 'r') as file:
            return list(map(float, file.readlines()))
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return []
    except ValueError:
        print(f"Error: The file '{filename}' contains non-numeric data.")
        return []

def compute_average(numbers):
    """
    Computes the average of a list of numbers.
    
    Args:
    numbers (list of float): The list of numbers to average.
    
    Returns:
    float: The average of the numbers.
    """
    return sum(numbers) / len(numbers) if numbers else 0

def main():
    filename = input("Enter the name of the file: ")
    numbers = read_numbers_from_file(filename)
    if numbers:  # Proceed only if the file was read successfully
        average = compute_average(numbers)
        print(f"The average of the numbers in {filename} is {average}")
    else:
        print("No numbers to average due to file read error.")

if __name__ == "__main__":
    main()
