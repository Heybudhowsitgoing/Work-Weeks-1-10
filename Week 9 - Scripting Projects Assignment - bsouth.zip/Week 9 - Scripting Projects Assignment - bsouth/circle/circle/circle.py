import turtle
import math

def drawCircle(t, centerX, centerY, radius):
    # Calculate the distance to move each step
    step_length = 2.0 * math.pi * radius / 120.0

    # Move the turtle to the starting point of the circle
    t.penup()
    t.goto(centerX + radius, centerY)
    t.pendown()
    
    # Draw the circle by turning 3 degrees and moving step_length 120 times
    for _ in range(120):
        t.forward(step_length)
        t.left(3)

# Example usage:
if __name__ == "__main__":
    screen = turtle.Screen()
    t = turtle.Turtle()
    drawCircle(t, 0, 0, 100)
    screen.mainloop()

