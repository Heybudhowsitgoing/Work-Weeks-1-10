
def inputFloat(prompt):
    """
    Prompts the user for a floating-point number and validates the input.

    Args:
    prompt (str): The prompt to display to the user.

    Returns:
    float: The validated floating-point number entered by the user.
    """
    while True:
        user_input = input(prompt)
        
        try:
            value = float(user_input)
            return value
        except ValueError:
            print("Invalid input. Please enter a valid floating-point number.")

if __name__ == "__main__":
    num = inputFloat("Enter a floating-point number: ")
    print(f"You entered: {num}")
